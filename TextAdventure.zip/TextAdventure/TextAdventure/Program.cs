﻿using System;
using DefaultEcs;

namespace TextAdventure
{
    class Program
    {
        static void Main(string[] args)
        {
            using var world = new World();

            world.CreateEntity().Dispose();
        }
    }
}
