﻿using Adventure.GameEngine.Interfaces;
using Adventure.TextProcessing.Interfaces;
using DefaultEcs;
using DefaultEcs.System;

namespace Adventure.GameEngine
{
    public interface IRoomFactory
    {
        void Initialize(Entity entity);

        IRoom Create();

        ISystem<ICommand> CreateCommandRunner();
    }
}