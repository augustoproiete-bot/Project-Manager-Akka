﻿using System.Collections.Generic;
using Adventure.GameEngine.Interfaces;
using Adventure.TextProcessing.Interfaces;
using DefaultEcs.System;

namespace Adventure.GameEngine.Systems
{
    public sealed class RoomRegistry
    {
        private readonly IEnumerable<IRoomFactory> _factories;
        private readonly IGame _game;

        public RoomRegistry(IEnumerable<IRoomFactory> factories, IGame game)
        {
            _factories = factories;
            _game = game;
        }

        public ISystem<ICommand> Init()
        {
            
        }
    }
}