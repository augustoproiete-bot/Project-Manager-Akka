﻿namespace Adventure.GameEngine.Componetns
{
    public sealed class DroppedItem
    {
        
    }
}