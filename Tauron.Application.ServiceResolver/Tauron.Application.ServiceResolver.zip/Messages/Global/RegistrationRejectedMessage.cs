﻿namespace Tauron.Application.Akka.ServiceResolver.Messages.Global
{
    public class RegistrationRejectedMessage
    {
    }
}