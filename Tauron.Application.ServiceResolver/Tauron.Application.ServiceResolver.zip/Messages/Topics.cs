﻿namespace Tauron.Application.Akka.ServiceResolver.Messages
{
    public static class Topics
    {
        public const string ServiceResolver = nameof(ServiceResolver);
    }
}