﻿using Akka.Actor;

namespace Tauron.Application.Akka.ServiceResolver.Actor
{
    public abstract class ResolveActorBase : ReceiveActor
    {
    }
}